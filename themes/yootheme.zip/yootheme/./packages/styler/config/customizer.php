<?php

return [
    'sections' => [
        'styler' => [
            'title' => 'Style',
            'width' => 350,
            'priority' => 11,
        ],
    ],
];
