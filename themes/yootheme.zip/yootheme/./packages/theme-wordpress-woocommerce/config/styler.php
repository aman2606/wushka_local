<?php

return [
    'components' => [
        'woocommerce' => [
            'name' => 'WooCommerce',
            'general' => true,
            'groups' => [
                'product page price' => '@woocommerce-product-page-price-*',
                'product page price from' => '@woocommerce-product-page-price-from-*',
                'product page rating' => '@woocommerce-product-page-rating-*',
                'product page title' => '@woocommerce-product-page-title-*',
                'product page add to cart' => '@woocommerce-product-page-add-to-cart-*',
                'shop page price' => '@woocommerce-shop-page-price-*',
                'shop page rating' => '@woocommerce-shop-page-rating-*',
                'shop page title' => '@woocommerce-shop-page-title-*',
                'price' => '@woocommerce-price-*',
                'rating' => '@woocommerce-rating-*',
                'review link' => '@woocommerce-review-link-*',
                'cart page' => '@woocommerce-cart-page-*',
                'checkout page' => '@woocommerce-checkout-page-*',
                'order page' => '@woocommerce-order-page-*',
                'myaccount page' => '@woocommerce-myaccount-page-*',
                'widget' => '@woocommerce-widget-*',
                'widget active filters' => '@woocommerce-widget-active-filters-*',
                'filter element' => '@woocommerce-filter-element-*',
                'alert' => '@woocommerce-alert-*',
            ],
        ],
    ],
];
