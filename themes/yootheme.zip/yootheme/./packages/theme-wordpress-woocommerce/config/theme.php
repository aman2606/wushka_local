<?php

return [
    'defaults' => [
        'woocommerce' => [
            'product_thumbnails_columns' => '4',
            'cross_sells_columns' => '2',
        ],
    ],
];
