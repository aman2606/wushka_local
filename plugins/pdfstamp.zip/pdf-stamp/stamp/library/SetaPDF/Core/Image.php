<?php
/**
 * This file is part of the SetaPDF-Core Component
 *
 * @copyright  Copyright (c) 2012 Setasign - Jan Slabon (http://www.setasign.de)
 * @category   SetaPDF
 * @package    SetaPDF_Core
 * @subpackage Document
 * @license    http://www.setasign.de/ Commercial
 * @version    $Id: Image.php 364 2012-12-06 11:30:03Z maximilian $
 */

/**
 * Base class for image handling
 * 
 * This class is responsible for getting the correct image type implementation for
 * a desired image type.
 * 
 * Actually PNG and JPEG classes exist. 
 *
 * @copyright  Copyright (c) 2012 Setasign - Jan Slabon (http://www.setasign.de)
 * @category   SetaPDF
 * @package    SetaPDF_Core
 * @subpackage Image
 * @license    http://www.setasign.de/ Commercial
 */
abstract class SetaPDF_Core_Image
{
    /**#@+
     * Image type
     *
     * @var string
     */
    const TYPE_JPEG = 'jpeg';
    const TYPE_GIF = 'gif';
    const TYPE_JPEG2000 = 'jpeg2000';
    const TYPE_PNG = 'png';
    const TYPE_TIFF = 'tiff';
    const TYPE_UNKNOWN = 'unknown';
    /**#@-*/

    /**
     * Binary Reader
     *
     * @var SetaPDF_Core_Reader_Binary
     */
    protected $_binaryReader;

    /**
     * Bits per component
     *
     * @var integer
     */
    protected $_bitsPerComponent = 8;

    /**
     * The pixel width
     *
     * @var integer
     */
    protected $_width;

    /**
     * The pixel height
     *
     * @var integer
     */
    protected $_height;

    /**
     * Dots-per-inch in the X direction
     *
     * @var integer
     */
    protected $_dpiX = 0;

    /**
     * Dots-per-inch in the Y direction
     *
     * @var integer
     */
    protected $_dpiY = 0;

    /**
     * The image type specific colorspace
     *
     * @var integer
     */
    protected $_colorSpace = -1;

    /**
     * Flag for color inversion
     *
     * @var boolean
     * todo Use it
     */
    protected $_inverted = false;

    /**
     * Get an image by a reader
     *
     * @param SetaPDF_Core_Reader_Interface $reader
     * @throws SetaPDF_Exception_NotImplemented
     * @return SetaPDF_Core_Image
     */
    static public function get(SetaPDF_Core_Reader_Interface $reader)
    {
        $type = self::getType($reader);
        switch ($type) {
            case self::TYPE_JPEG:
                return new SetaPDF_Core_Image_Jpeg($reader);

            case self::TYPE_PNG:
                return new SetaPDF_Core_Image_Png($reader);
                
            case self::TYPE_JPEG2000:
                return new SetaPDF_Core_Image_Jpeg2000($reader);
                
            default:
                throw new SetaPDF_Exception_NotImplemented('Image type "' . $type . '" not implemented.');
        }
    }

    /**
     * Get an image by a path
     *
     * @param string $path
     * @return SetaPDF_Core_Image
     */
    static public function getByPath($path)
    {
        return self::get(new SetaPDF_Core_Reader_File($path));
    }

    /**
     * Get an image type by a reader
     *
     * @param SetaPDF_Core_Reader_Interface $reader
     * @return string
     */
    static public function getType(SetaPDF_Core_Reader_Interface $reader)
    {
        $currentPos = $reader->getPos();
        $reader->reset(0, 12);
        $bytes = $reader->getBuffer();
        $type = self::TYPE_UNKNOWN;

        switch (1) {
            case $bytes[0] == "\xFF" && $bytes[1] == "\xD8":
                $type = self::TYPE_JPEG;
                break;

            case strpos($bytes, "\x89" . 'PNG' . "\x0D\x0A\x1A\x0A") === 0:
                $type = self::TYPE_PNG;
                break;

            case strpos($bytes, 'GIF') === 0:
                $type = self::TYPE_GIF;
                break;

            case $bytes == "\x00\x00\x00\x0C\x6A\x50\x20\x20\x0D\x0A\x87\x0A":
                $type = self::TYPE_JPEG2000;
                break;

            case $bytes[0] == 'M' && $bytes[1] == 'M' && $bytes[2] == "\x00" && $bytes[3] == "\x2A":
            case $bytes[0] == 'I' && $bytes[1] == 'I' && $bytes[2] == "\x2A" && $bytes[3] == "\x00":
                $type = self::TYPE_TIFF;
                break;
        }

        if (0 !== $currentPos)
            $reader->reset($currentPos);

        return $type;
    }

  /** Main object methods **/

    /**
     * The constructor
     *
     * @param SetaPDF_Core_Reader_Interface $reader
     */
    public function __construct(SetaPDF_Core_Reader_Interface $reader = null)
    {
        if ($reader !== null) {
            $this->_binaryReader = new SetaPDF_Core_Reader_Binary($reader);
            $this->_process();
        }
    }

    /**
     * Processes the image data so all needed informations are available
     */
    abstract protected function _process();

    /**
     * Converts an image to an external object
     *
     * @param SetaPDF_Core_Document $document
     * @return SetaPDF_Core_XObject_Image
     */
    abstract public function toXObject(SetaPDF_Core_Document $document);

    /**
     * Get the bits per component value
     *
     * @return number
     */
    public function getBitsPerComponent()
    {
        return $this->_bitsPerComponent;
    }

    /**
     * Get the width
     *
     * @param float $height Value for keeping the aspect ratio
     * @return number
     */
    public function getWidth($height = null)
    {
        if (null === $height)
            return $this->_width;

        return $height * $this->_width / $this->getHeight();
    }

    /**
     * Get the height
     *
     * @param float $width Value for keeping the aspect ratio
     * @return number
     */
    public function getHeight($width = null)
    {
        if (null === $width)
            return $this->_height;

        return $width * $this->_height / $this->getWidth();
    }

    /**
     * Get the dots-per-inch in the X direction
     *
     * @return number
     */
    public function getDpiX()
    {
        return $this->_dpiX;
    }

    /**
     * Get the dots-per-inch in the Y direction
     *
     * @return number
     */
    public function getDpiY()
    {
        return $this->_dpiY;
    }

    /**
     * Get the image type specific colorspace
     *
     * @return number
     */
    public function getColorSpace()
    {
        return $this->_colorSpace;
    }
}